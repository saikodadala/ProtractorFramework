var homePage = requirePage('homePage')   
var testName = 'TCAU01'
    
    

describe('TC01_AngularTest', function () {
    appLogger.Log("************************ Execution Started ***************************")
    appLogger.Log("************************ " + __filename + "***************************")

    beforeEach(function () {
        global.current_TestCase = "TC01_AngularTest"
    })

    it('TC01_AngularTest#Open Home Page', function () {
        homePage.openHome('AngularURL')
    })
    it('TC01_AngularTest#google search', function () {
        homePage.clickOnGetStartedButton()
    })
    
    

});